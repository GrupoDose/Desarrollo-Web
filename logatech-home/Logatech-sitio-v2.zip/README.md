# Logatech · Sitio web

## Versión corregida (carpeta `sitio-v2/`)

`sitio-v2/` es la copia corregida del sitio (fichas validadas, imágenes de producto pendientes, cotizador sincronizado, política de pedido única y promesas ajustadas). Se genera con `python3 build.py src-v2 sitio-v2`. Los originales `src/` y `sitio/` se conservan sin cambios. Ver `sitio-v2/CAMBIOS-v2.md` (resumen y pruebas) y `sitio-v2/FUENTES-Y-PENDIENTES.md` (fuentes, claves por confirmar, datos e imágenes pendientes).


## Sitio completo (carpeta `sitio/`)

El cliente eligió la propuesta 1 (Catálogo Pro). A partir de ella está construido el sitio completo, con el mismo sistema de diseño, la paleta del logotipo y fotografía real:

| Página | Archivo | Qué hace |
|--------|---------|----------|
| Inicio | `sitio/inicio.html` | Hero por audiencia, marcas, "Más pedidos" (productos con `home:true`), categorías, por qué Loga, CTA. |
| Catálogo | `sitio/catalogo.html` | Filtros por categoría, subcategoría y marca; búsqueda (`?q=`); orden; paginación; estado vacío con cotización. Parámetros: `?cat=antidoping&sub=…&marca=…&q=…&orden=az&p=2`. |
| Producto | `sitio/producto.html?sku=DOA164` | Ficha completa estilo Amazon adaptado: galería, viñetas, especificaciones, caja de cotización, pestañas, documentos (ficha técnica, hoja de seguridad, certificado por WhatsApp) y relacionados. |
| Nosotros | `sitio/nosotros.html` | Historia, cifras, diferenciadores, lo que no hacemos, a quién atendemos, razón social. |
| Marcas | `sitio/marcas.html` | Las 43 marcas del cuestionario con buscador y filtro por letra; enlaza al catálogo filtrado por marca o a cotización con asesor. |
| Servicio técnico | `sitio/servicio-tecnico.html` | Qué incluye, proceso en 4 pasos, equipos atendidos, formulario "Agendar servicio". |
| Envíos y crédito | `sitio/envios-y-credito.html` | Políticas de envío, cadena de frío, crédito, garantía y pagos; preguntas frecuentes. |
| Contacto | `sitio/contacto.html` | Vías de contacto, los 8 teléfonos, horario, mapa, formulario de cotización (se prellena con la cotización guardada). |

Funciones compartidas en todas las páginas:

- **Cotización persistente**: el botón "Cotización" guarda productos en el navegador (`localStorage`); el cajón "Mi cotización" permite ajustar cantidades, agregar notas y enviar por WhatsApp o correo con el mensaje armado.
- **Vista rápida** (modal) desde cualquier tarjeta y enlace a la ficha completa.
- **Buscador del header** que lleva al catálogo con la categoría seleccionada.
- **Menú móvil**, navegación de categorías y listas del footer generadas desde los datos.
- **Formularios sin backend**: arman el mensaje y abren WhatsApp o el correo. Se pueden sustituir por Elementor Forms cuando se quiera guardar leads.

### Cómo se construye

Los archivos de `sitio/` se generan con `python3 build.py` a partir de `src/` (y `sitio-v2/` con `python3 build.py src-v2 sitio-v2` a partir de `src-v2/`):

- `src/data.js`: configuración (`CFG`, incluidos los slugs de cada página), categorías, marcas y los 33 productos del cuestionario. **Aquí se agregan productos**: cada uno con categoría, subcategoría, marca, clave, presentación, viñetas, especificaciones, descripción y foto.
- `src/core.js`: cotización, modal, enlaces, formularios, menú.
- `src/base.css` + `src/extra.css`: estilos; `src/header.html`, `src/footer.html`, `src/overlays.html`: partes comunes.
- `src/pages/*.html`: cada página (CSS propio, HTML y JS separados por marcadores).

Cada archivo generado es autónomo: se pega completo en un widget HTML de Elementor, una página de WordPress por archivo. Antes de publicar, en `src/data.js` cambia `CFG.pages` por los slugs reales (por ejemplo `catalogo:'/catalogo/'`) y vuelve a construir; todos los enlaces internos se actualizan. La ficha de producto es una sola página de WordPress que lee `?sku=`.

### Decisiones a confirmar con el cliente

- Se agregó una décima categoría, **Consumibles y toma de muestra**, para los tubos BD, vasos de orina, cajas Petri, portaobjetos y medios de transporte del listado de más vendidos, que no caben en las 9 categorías del cuestionario.
- El tubo rojo BD de 6 ml trae la misma clave que el amarillo en el cuestionario; quedó como "Por confirmar".
- Especificaciones de producto escritas como referencia: validar contra las fichas técnicas del fabricante.
- Point of care, cuidados críticos, detección de alcohol y equipos no tienen SKUs en el cuestionario; el catálogo muestra un estado "se cotiza con asesor" hasta que lleguen los productos.

---

# Propuestas de diseño (fase 1) · 5 propuestas

Propuestas de diseño para la nueva web de **Loga Soluciones Científicas para Laboratorio** (razón social: Logatech Corporation Industrial S.A. de C.V.), construidas a partir del cuestionario de rediseño y del boceto de la página de inicio.

Abre `index.html` para ver el índice, o cada archivo directamente:

| # | Archivo | Referencia | Idea |
|---|---------|------------|------|
| 1 | `01-catalogo-ctr.html` | ctrscientific.com | Catálogo tipo e-commerce: buscador, barra de categorías, tarjetas de producto, carrito de cotización. |
| 2 | `02-minimal-apple.html` | apple.com/mx | Minimal premium: tipografía grande, tiles blanco/negro, hero full-screen con crossfade. |
| 3 | `03-corporativo-labs.html` | Thermo Fisher · Sartorius · Eppendorf · bioMérieux | Corporativo científico: pestañas por cliente, catálogo, recursos, formulario B2B. |
| 4 | `04-futurista-salud.html` | — | Bio-futurista: fondo profundo, brillos cian/verde, cristal, ECG, ADN. |
| 5 | `05-editorial-bento.html` | — (libre) | Editorial bento: fondo cálido, serif, retícula bento, carrusel, barra sticky WhatsApp. |

## Componentes del boceto (presentes en las 5)

- **Hero enfocado en 4 audiencias** con flechas, indicadores, autoplay y transición distinta en cada propuesta: deslizamiento + Ken Burns (1), crossfade + desenfoque (2), revelado circular (3), barrido con línea de escaneo (4), volteo 3D (5). Audiencias: Hospitales · Laboratorios clínicos · Empresas con reclutamiento · Industria.
- **Marcas con las que trabajamos** (marquee o retícula con las marcas autorizadas del cuestionario).
- **Más pedidos en todo México**: 6 productos reales del cuestionario (DOA164, 368171, CAGD025E, PT7114, 64840, IDEC-425). Al hacer clic se abre un **pop-up de producto estilo Amazon adaptado** al diseño: miniaturas, imagen grande, viñetas "Acerca de este producto", tabla de especificaciones, caja de compra con cantidad, "Agregar a cotización", "Cotizar por WhatsApp" (arma el mensaje con producto, clave y cantidad), pestañas (descripción, especificaciones, envío y garantía) y productos relacionados.
- **Categorías**: las 4 principales destacadas + las otras 5 del cuestionario como accesos rápidos.
- Extras del cuestionario: envío gratis desde $5,000, cadena de frío lunes y miércoles, registro COFEPRIS, servicio técnico propio, crédito a 15 y 30 días, equipos nuevos de fábrica, contacto real y redes.

## Subir a Elementor

1. Abre el `.html` en un editor de texto.
2. Copia todo lo que está entre `<!-- ===== INICIO BLOQUE ELEMENTOR ===== -->` y `<!-- ===== FIN BLOQUE ELEMENTOR ===== -->`.
3. Página nueva con plantilla **Elementor Canvas** (o Full Width si conservas header/footer del tema; en ese caso borra el `<header>`/`<nav>` y `<footer>` del bloque).
4. Sección de ancho completo, sin padding → widget **HTML** → pegar → publicar.
5. En el `<script>` ajusta `CFG.logoUrl` (URL del logo subido a Medios) y `CFG.whatsapp`.

Notas técnicas:

- Sin jQuery ni librerías externas; solo Google Fonts.
- CSS aislado por prefijo (`#lg1`…`#lg5`) para no chocar con el tema. El modal (`#lgN-modal`) y el botón flotante de WhatsApp se mueven a `<body>` al cargar, para que `position:fixed` funcione aunque la sección de Elementor tenga efectos de movimiento (transform). Probado simulando el pegado dentro de una sección con `transform`.
- Los colores de marca están en variables CSS al inicio de cada `<style>` (`--navy`, `--blue`, `--green`) y se cambian en un solo lugar.
- Las ilustraciones de producto y del hero son SVG de relleno. Para poner fotos reales, cambia `ART[...]` o agrega `img` en el arreglo `PRODUCTS`.
- Precios: `price: null` muestra "Precio por cotización"; con un número muestra `$1,234.00 MXN + IVA`.
- Verificado en Chromium (escritorio 1366 px y móvil 390 px) sin errores de JavaScript ni scroll horizontal.

## Paleta oficial (tomada del logotipo)

Colores medidos sobre el isotipo (cruz con cuatro pétalos): azul `#1842C0→#4A9EDA`, naranja `#D88A30`, verde `#6CA236`, rojo `#BA2418`. Azul es el color principal y naranja el secundario. Aplicada en las propuestas 1, 3 y 4 mediante variables al inicio de cada `<style>`:

| Token | Hex | Uso |
|-------|-----|-----|
| `--brand-blue` | `#2F7FD3` | color principal: enlaces, iconos, ilustraciones, gradientes |
| `--brand-blue-d` | `#1F5FBF` | botones primarios y texto sobre blanco (contraste AA) |
| `--brand-blue-l` | `#4A9EDA` | brillos y gradientes sobre fondo oscuro (propuesta 4) |
| `--brand-orange` | `#E08A2E` | secundario: badges, acentos, palabras destacadas, barras de progreso |
| `--brand-orange-d` | `#C46F1C` | CTAs secundarios con texto blanco (cotizar, WhatsApp) |
| `--brand-green` | `#5FA33A` | solo señales positivas: disponibilidad, checks, COFEPRIS |
| `--brand-ink` | `#12305E` | texto, franjas oscuras, footer |
| `--brand-grad` | azul → azul claro → naranja | líneas finas de acento y pestañas activas |

El isotipo real va incrustado (base64) en el logotipo de respaldo de cada propuesta; `CFG.logoUrl` sigue disponible para el archivo completo con wordmark. Las propuestas 2 y 5 conservan la paleta anterior hasta que se pida el cambio.

## Fotografías

Propuestas 1, 3 y 4 usan fotos de **Pexels** (licencia libre, sin atribución) por audiencia (hospital, laboratorio, reclutamiento, industria), por categoría y por producto. Cada `<img>` trae respaldo: si la URL no carga, se muestra la ilustración SVG. Los IDs están en `PHOTOS` y en el campo `img` de `PRODUCTS`; para fotos propias súbelas a Medios y cambia la función `px()` o los IDs. Recomendado antes de publicar: descargar las fotos elegidas y servirlas desde el propio WordPress.

## Pendientes que dependen del cliente

- **Logo oficial**: el entorno no pudo descargar `logatech.mx` (bloqueado por la red), así que cada propuesta trae un logotipo SVG de respaldo y un campo `CFG.logoUrl` para el archivo real.
- Tipografía: se usaron familias de Google Fonts afines; se cambian en `--font-h`/`--font-b` si el manual indica otras.
- Fotos de producto, catálogos PDF y logos de marcas: sustituir los SVG cuando llegue el Drive del cliente.
